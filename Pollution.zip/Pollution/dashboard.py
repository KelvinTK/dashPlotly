import pathlib
import os
import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.express as px
app_path = str(pathlib.Path(__file__).parent.resolve())
df = pd.read_csv(os.path.join(app_path, os.path.join("data", "pollution.csv")))
app = dash.Dash(__name__, url_base_pathname='/dashboard/')
server = app.server
theme = {
    'background': '#111111',
    'text': '#7FDBFF'
}
def build_banner():
    return html.Div(
        className='col-sm-10 row banner',
        children=[
            html.Div(
                className='banner-text',
                children=[
                    html.H5('CARBON MONOXIDE POLLUTION FOR AUG & SEPT, 2014 IN THE UK'),
                ],
            ),
        ],
    )


# format dates
df['day'] = pd.to_datetime(df.timestamp, utc=True).dt.day;
df['month'] = pd.to_datetime(df.timestamp, utc=True).dt.month;
df['year'] = pd.to_datetime(df.timestamp, utc=True).dt.year;


# seperate by months
def build_graph():
    return dcc.Graph(
        id='basic-interactions',
        figure={
            'data': [
                {
                    'x': df[(df.month == 8)]['day'],
                    'y': df[(df.month == 8)]['carbon_monoxide'],
                    'name': 'CO polllution for August',
                    'type': 'bar',

                },
                {
                    'x': df[(df.month == 9)]['day'],
                    'y': df[(df.month == 9)]['carbon_monoxide'],
                    'name': 'CO pollution for September',
                    'type': 'bar'
                },
            ],
        }
    )


# def poll_scatter():
#   return dcc.Graph(
#          id='basic-interactions'
#         figure={
#            'data':[{
#                   'x':df[(df.month==8)]['day'],
#                  'y':df[(df.month==8)]['sulfure_dioxide'],
#                        'name':'SO2 pollution for August'
#                       'marker':{'symbol':'circle'},
#                      'mode':'markers',
#                     'showlegend':True,
#                },
#               {
#                  'x':df[(df.month==9)]['day'],
#                 'y':df[(df.month==9)]['sulfure_dioxide'],
#                'name':'SO2 polution for September',
#                        'marker':{'symbol':'circle'},
#                       'mode':'markers',
#                      'showlegend':True,
#                     },
#                ],
#           }
#      )

app.layout = html.Div(
    className='big-app-container',
    children=[
        build_banner(),
        html.Div(
            className='app-container',
            children=[
                build_graph(),
            ]
        )
    ]
)

